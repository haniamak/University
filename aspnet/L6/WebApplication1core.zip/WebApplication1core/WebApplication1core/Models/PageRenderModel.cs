﻿namespace WebApplication1core.Models

{
	public class PageRenderModel
	{
		public string Site { get; set; }
		public string Page { get; set; }
	}
}
